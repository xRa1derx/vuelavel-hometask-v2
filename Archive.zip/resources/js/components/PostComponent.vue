<template>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center">Post section</h1>
                <label for="title" class="form-label">Add a new title</label>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="title" />
                </div>
                <label for="content">Text</label>
                <div class="form-floating mb-3">
                    <textarea
                        class="form-control"
                        placeholder="Leave a new content here"
                        id="content"
                        style="height: 100px"
                    ></textarea>
                </div>
                <button @click="test">test</button>
            </div>
        </div>
    </div>
</template>

<script>
import axios from "axios";
export default {
    created() {
        this.test();
        console.log('test');
    },
    methods: {
        test() {
            axios.get("/api/admin").then((res) => console.log(res));
        },
    },
};
</script>

<style></style>
